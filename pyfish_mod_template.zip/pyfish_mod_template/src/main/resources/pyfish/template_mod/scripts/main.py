from pyfish import BlockBreakEvent, PlayerEvent, log_print, mc


def on_player_join(event: PlayerEvent) -> None:
    player = event.getPlayer() or event.getEntity()
    if player is not None:
        mc.send_message(player, "TemplateMod is running through PyFish.")


def on_block_break(event: BlockBreakEvent) -> None:
    player = event.getPlayer()
    pos = event.getPos()
    if player is None or pos is None:
        return
    mc.send_message(player, f"Block broken at {pos.getX()} {pos.getY()} {pos.getZ()}")


mc.on("on_player_join", on_player_join)
mc.on("on_block_break", on_block_break)
log_print("Template mod loaded")
