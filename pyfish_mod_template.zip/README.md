# PyFish Mod JAR Template

This template creates two normal Minecraft mod JARs containing Python scripts:

- one JAR for Fabric
- one JAR for NeoForge

Use this format when the project must appear in the loader's mod list or when
another mod needs to declare it as a dependency. For a simpler Python-only mod
that uses the same file on both loaders, use the `.pyz` template instead.

## Requirements

- Java 21
- PyFish installed in the Minecraft instance
- Fabric API when using the Fabric build

No Java source code is required. The JAR contains loader metadata and PyFish
scripts.

## Create your mod

1. Edit `gradle.properties`.
2. Choose a unique lowercase `mod_id`.
3. Rename
   `src/main/resources/pyfish/template_mod/` to
   `src/main/resources/pyfish/<your_mod_id>/`.
4. Write scripts in that folder's `scripts/` directory.
5. Put static resources in `src/main/resources/assets/<your_mod_id>/...` and
   `src/main/resources/data/<namespace>/...` when needed.
6. Add pure-Python dependencies to `requirements.txt` when needed.
7. Build both loader JARs:

```text
gradlew.bat build
```

On Linux or macOS, run `./gradlew build`.

The generated files are:

```text
build/libs/<mod_id>-fabric-<version>.jar
build/libs/<mod_id>-neoforge-<version>.jar
```

Install only the JAR matching the loader, next to the normal PyFish JAR in the
Minecraft `mods/` folder.

## Namespace

Scripts bundled in this template automatically use the real loader mod id.

For example:

```python
items.register_item("ruby", {...})
blocks.register_block("ruby_block", {...})
```

With `mod_id=ruby_tools`, those registrations become
`ruby_tools:ruby` and `ruby_tools:ruby_block`.

## Project layout

```text
pyfish_mod_template/
|-- gradle.properties
|-- build.gradle
|-- gradlew.bat
|-- gradlew
`-- src/main/resources/
    |-- fabric.mod.json
    |-- META-INF/neoforge.mods.toml
    |-- assets/<your_mod_id>/...
    |-- data/<namespace>/...
    `-- pyfish/template_mod/
        |-- requirements.txt
        `-- scripts/main.py
```
