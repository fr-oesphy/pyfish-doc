"""IDE-friendly facade mirroring the bundled `java_pathlib` module."""

from pathlib import Path

__all__ = ["Path"]
