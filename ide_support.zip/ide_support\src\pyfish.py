"""IDE shim for PyFish.

This module mirrors the public Python surface shipped by the PyFish Minecraft mod
so editors can resolve imports, signatures, callback shapes, and docstrings
outside Minecraft.

It is intentionally permissive and lightweight: the goal is editor support, not a
full Minecraft simulation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterable, List, Mapping, MutableMapping, Optional, TypedDict
from uuid import uuid4


Callback = Callable[..., Any]


def log_print(*args: object) -> None:
    """Log a message exactly like PyFish runtime scripts do."""
    print(" ".join(str(arg) for arg in args))


@dataclass
class MessageHandle:
    """Simple text wrapper matching `event.getMessage().getString()` and `entity.getName()`."""

    text: str = ""

    def getString(self) -> str:
        return self.text

    def __str__(self) -> str:
        return self.text


@dataclass
class GameProfileHandle:
    """Minimal game-profile object exposed by player wrappers."""

    name: str = "Player"
    uuid: str = field(default_factory=lambda: str(uuid4()))

    def getName(self) -> str:
        return self.name

    def getId(self) -> str:
        return self.uuid


@dataclass
class TextureHandle:
    """Represents a loaded texture-like object for hover/autocomplete purposes."""

    texture_id: str
    width: int = 16
    height: int = 16

    def getWidth(self) -> int:
        return self.width

    def getHeight(self) -> int:
        return self.height


@dataclass
class BlockPosHandle:
    """Lightweight position handle exposed to IDEs and local tests."""

    x: int = 0
    y: int = 0
    z: int = 0

    def getX(self) -> int:
        return self.x

    def getY(self) -> int:
        return self.y

    def getZ(self) -> int:
        return self.z

    def unwrapBlockPos(self) -> "BlockPosHandle":
        return self


@dataclass
class ServerHandle:
    """Server wrapper used by lifecycle callbacks."""

    name: str = "PyFish IDE Server"
    worlds: List["WorldHandle"] = field(default_factory=list)

    def unwrapServer(self) -> "ServerHandle":
        return self

    def getWorlds(self) -> List["WorldHandle"]:
        return list(self.worlds)


@dataclass
class WorldHandle:
    """World wrapper used by PyFish callbacks and world-manipulation helpers."""

    name: str = "minecraft:overworld"
    time: int = 0
    server: Optional[ServerHandle] = None
    blocks: MutableMapping[tuple[int, int, int], str] = field(default_factory=dict)
    players: List["PlayerHandle"] = field(default_factory=list)
    entities: List["EntityHandle"] = field(default_factory=list)

    def unwrapLevel(self) -> "WorldHandle":
        return self

    def getServer(self) -> Optional[ServerHandle]:
        return self.server


@dataclass
class EntityHandle:
    """Base entity wrapper matching the Java handles exposed by PyFish events."""

    name: str = "entity.minecraft.pig"
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    level: Optional[WorldHandle] = None
    uuid: str = field(default_factory=lambda: str(uuid4()))
    alive: bool = True

    def unwrapEntity(self) -> "EntityHandle":
        return self

    def getName(self) -> MessageHandle:
        return MessageHandle(self.name)

    def getX(self) -> float:
        return self.x

    def getY(self) -> float:
        return self.y

    def getZ(self) -> float:
        return self.z

    def getBlockX(self) -> int:
        return int(self.x)

    def getBlockY(self) -> int:
        return int(self.y)

    def getBlockZ(self) -> int:
        return int(self.z)

    def getUUID(self) -> str:
        return self.uuid

    def serverLevel(self) -> Optional[WorldHandle]:
        return self.level

    def isAlive(self) -> bool:
        return self.alive


@dataclass
class PlayerHandle(EntityHandle):
    """Player wrapper used by PyFish callbacks."""

    hunger: int = 20
    health: float = 20.0
    experience_level: int = 0
    inventory: List[tuple[str, int]] = field(default_factory=list)
    profile: GameProfileHandle = field(default_factory=GameProfileHandle)

    def __post_init__(self) -> None:
        if self.profile.name == "Player":
            self.profile.name = self.name

    def unwrapPlayer(self) -> "PlayerHandle":
        return self

    def getGameProfile(self) -> GameProfileHandle:
        return self.profile

    def getHealth(self) -> float:
        return self.health

    def getFoodLevel(self) -> int:
        return self.hunger

    def getExperienceLevel(self) -> int:
        return self.experience_level


@dataclass
class ItemUseOnContextHandle:
    """Context object used by dynamic `use_on` item callbacks."""

    level: Optional[WorldHandle] = None
    player: Optional[PlayerHandle] = None
    pos: BlockPosHandle = field(default_factory=BlockPosHandle)
    hand: str = "MAIN_HAND"
    item_in_hand: str = "minecraft:stick"

    def unwrapContext(self) -> "ItemUseOnContextHandle":
        return self

    def getLevel(self) -> Optional[WorldHandle]:
        return self.level

    def getPlayer(self) -> Optional[PlayerHandle]:
        return self.player

    def getClickedPos(self) -> BlockPosHandle:
        return self.pos

    def getHand(self) -> str:
        return self.hand

    def getItemInHand(self) -> str:
        return self.item_in_hand


@dataclass
class CallbackEvent:
    """Generic callback event surface shared by many PyFish event aliases."""

    player: Optional[PlayerHandle] = None
    entity: Optional[EntityHandle] = None
    level: Optional[WorldHandle] = None
    server: Optional[ServerHandle] = None
    pos: Optional[BlockPosHandle] = None
    message: MessageHandle = field(default_factory=MessageHandle)
    target: Optional[EntityHandle] = None
    hand: str = "MAIN_HAND"

    def getPlayer(self) -> Optional[PlayerHandle]:
        return self.player

    def getEntity(self) -> Optional[EntityHandle]:
        return self.entity or self.player

    def getLevel(self) -> Optional[WorldHandle]:
        return self.level

    def getServer(self) -> Optional[ServerHandle]:
        return self.server

    def getPos(self) -> Optional[BlockPosHandle]:
        return self.pos

    def getMessage(self) -> MessageHandle:
        return self.message

    def getMessageString(self) -> str:
        return self.message.getString()

    def getTarget(self) -> Optional[EntityHandle]:
        return self.target

    def getHand(self) -> str:
        return self.hand


@dataclass
class ServerEvent:
    """Server lifecycle event wrapper."""

    server: ServerHandle = field(default_factory=ServerHandle)

    def getServer(self) -> ServerHandle:
        return self.server

    def unwrapServer(self) -> ServerHandle:
        return self.server


@dataclass
class LevelEvent:
    """World lifecycle event wrapper."""

    level: WorldHandle = field(default_factory=WorldHandle)

    def getLevel(self) -> WorldHandle:
        return self.level

    def unwrapLevel(self) -> WorldHandle:
        return self.level

    def getServer(self) -> Optional[ServerHandle]:
        return self.level.getServer()


@dataclass
class PlayerEvent(CallbackEvent):
    """Base player event wrapper."""


@dataclass
class PlayerCloneEvent(PlayerEvent):
    """Player clone/respawn style event wrapper."""

    old_player: Optional[PlayerHandle] = None
    alive_before_clone: bool = True

    def getOldPlayer(self) -> Optional[PlayerHandle]:
        return self.old_player

    def isAlive(self) -> bool:
        return self.alive_before_clone


@dataclass
class BlockBreakEvent(PlayerEvent):
    """Block break event wrapper."""


@dataclass
class BlockPlaceEvent(PlayerEvent):
    """Block placement event wrapper."""


@dataclass
class PlayerChatEvent(PlayerEvent):
    """Chat event wrapper exposing both `getMessage()` and `getMessageString()`."""


@dataclass
class EntityEvent(CallbackEvent):
    """Base entity event wrapper."""


@dataclass
class EntitySpawnEvent(EntityEvent):
    """Entity spawn event wrapper."""


@dataclass
class EntityDimensionChangeEvent(EntityEvent):
    """Entity dimension change event wrapper."""

    origin_level: Optional[WorldHandle] = None

    def getOriginLevel(self) -> Optional[WorldHandle]:
        return self.origin_level


@dataclass
class LivingEvent(EntityEvent):
    """Base living-entity event wrapper."""

    def getLivingEntity(self) -> Optional[EntityHandle]:
        return self.getEntity()


@dataclass
class LivingDamageEvent(LivingEvent):
    """Living-damage event wrapper."""

    amount: float = 0.0
    damage_taken: Optional[float] = None
    blocked: bool = False
    damage_source_name: str = "generic"

    def getAmount(self) -> float:
        return self.amount

    def getDamageTaken(self) -> float:
        return self.damage_taken if self.damage_taken is not None else self.amount

    def isBlocked(self) -> bool:
        return self.blocked

    def getDamageSourceName(self) -> str:
        return self.damage_source_name


@dataclass
class LivingDeathEvent(LivingEvent):
    """Living-death event wrapper."""

    damage_source_name: str = "generic"

    def getDamageSourceName(self) -> str:
        return self.damage_source_name


@dataclass
class PlayerInteractEvent(PlayerEvent):
    """Base player-interaction event wrapper."""


@dataclass
class PlayerInteractBlockEvent(PlayerInteractEvent):
    """Player right-click block event wrapper."""


@dataclass
class PlayerInteractEntityEvent(PlayerInteractEvent):
    """Player right-click entity event wrapper."""


@dataclass
class PlayerSleepInBedEvent(PlayerEvent):
    """NeoForge player sleep event forwarded directly by PyFish."""


@dataclass
class PlayerWakeUpEvent(PlayerEvent):
    """NeoForge player wake-up event forwarded directly by PyFish."""


@dataclass
class EntityTravelToDimensionEvent(EntityDimensionChangeEvent):
    """NeoForge dimension-travel event forwarded directly by PyFish."""


@dataclass
class LivingFallEvent(LivingEvent):
    """NeoForge living-fall event forwarded directly by PyFish."""

    distance: float = 0.0
    damage_multiplier: float = 1.0

    def getDistance(self) -> float:
        return self.distance

    def getDamageMultiplier(self) -> float:
        return self.damage_multiplier


@dataclass
class LivingHealEvent(LivingEvent):
    """NeoForge living-heal event forwarded directly by PyFish."""

    amount: float = 0.0

    def getAmount(self) -> float:
        return self.amount


@dataclass
class AnimalTameEvent(LivingEvent):
    """NeoForge animal-tame event forwarded directly by PyFish."""

    def getAnimal(self) -> Optional[EntityHandle]:
        return self.getLivingEntity()

    def getTamer(self) -> Optional[PlayerHandle]:
        return self.getPlayer()


@dataclass
class ItemTossEvent(PlayerEvent):
    """NeoForge item-toss event forwarded directly by PyFish."""

    item_id: str = "minecraft:stone"

    def getItem(self) -> str:
        return self.item_id


@dataclass
class ItemEntityPickupEvent(PlayerEvent):
    """NeoForge item-pickup event forwarded directly by PyFish."""

    item_id: str = "minecraft:stone"

    def getItem(self) -> str:
        return self.item_id


@dataclass
class CommandEvent(ServerEvent):
    """NeoForge command event forwarded directly by PyFish."""

    command: str = ""

    def getCommand(self) -> str:
        return self.command


class BlockEvent:
    """Namespace for NeoForge nested block event classes."""

    @dataclass
    class EntityPlaceEvent(PlayerInteractBlockEvent):
        """NeoForge block-placement event."""

    class CropGrowEvent:
        """Namespace for crop-grow events."""

        @dataclass
        class Post(CallbackEvent):
            """NeoForge crop-grow post event."""

            state: str = "minecraft:wheat"

            def getState(self) -> str:
                return self.state

    @dataclass
    class NeighborNotifyEvent(CallbackEvent):
        """NeoForge neighbor-notify event."""


class NoteBlockEvent:
    """Namespace for NeoForge note-block events."""

    @dataclass
    class Play(CallbackEvent):
        """NeoForge note-block play event."""

        note: int = 0

        def getVanillaNoteId(self) -> int:
            return self.note


class PlayerXpEvent:
    """Namespace for NeoForge XP events."""

    @dataclass
    class XpChange(PlayerEvent):
        """NeoForge XP-change event."""

        amount: int = 0

        def getAmount(self) -> int:
            return self.amount


class ExplosionEvent:
    """Namespace for NeoForge explosion events."""

    @dataclass
    class Detonate(CallbackEvent):
        """NeoForge explosion detonation event."""

        radius: float = 0.0

        def getExplosionRadius(self) -> float:
            return self.radius


@dataclass
class _PlayerItemCraftedEvent(PlayerEvent):
    """NeoForge crafted-item event attached as PlayerEvent.ItemCraftedEvent."""

    item_id: str = "minecraft:crafting_table"

    def getCrafting(self) -> str:
        return self.item_id


@dataclass
class _PlayerItemSmeltedEvent(PlayerEvent):
    """NeoForge smelted-item event attached as PlayerEvent.ItemSmeltedEvent."""

    item_id: str = "minecraft:iron_ingot"

    def getSmelting(self) -> str:
        return self.item_id


@dataclass
class _LivingJumpEvent(LivingEvent):
    """NeoForge living-jump event attached as LivingEvent.LivingJumpEvent."""


PlayerEvent.ItemCraftedEvent = _PlayerItemCraftedEvent
PlayerEvent.ItemSmeltedEvent = _PlayerItemSmeltedEvent
LivingEvent.LivingJumpEvent = _LivingJumpEvent


class PyFishModMetadata(TypedDict, total=False):
    """Metadata injected into the entrypoint of a packaged PyFish mod."""

    schema_version: int
    id: str
    name: str
    version: str
    description: str
    authors: List[str]
    license: str
    homepage: str
    dependencies: Mapping[str, List[str | "PyFishDependencyMetadata"]]


class PyFishDependencyMetadata(TypedDict, total=False):
    """Structured dependency entry accepted by `pyfish.mod.json`."""

    id: str
    version: str
    versionRange: str
    version_range: str


class EventCallbacks(TypedDict, total=False):
    """Known dynamic content callback keys accepted by PyFish items and blocks."""

    use: Callback
    use_on: Callback
    eat: Callback


class ItemProperties(TypedDict, total=False):
    """Properties accepted by `items.register_item()` and most dynamic item builders."""

    texture: str
    model: str
    stacksTo: int
    fireResistant: bool
    durability: int
    alwaysEdible: bool
    tab: str
    fabricFallbackTab: str
    repairItem: str
    damage: float
    attackSpeed: float
    damageBonus: float
    speed: float
    enchantmentValue: int
    events: Mapping[str, Callback]


class BlockProperties(TypedDict, total=False):
    """Properties accepted by `blocks.register_block()`."""

    texture: str | Mapping[str, str]
    destroyTime: float
    explosionResistance: float
    requiresCorrectToolForDrops: bool
    tab: str
    fabricFallbackTab: str
    events: Mapping[str, Callback]


class TabProperties(TypedDict, total=False):
    """Properties accepted by `tabs.create()`."""

    displayName: str
    icon: str
    fabricFallbackTab: str


class _RecipesApi:
    """Shim for recipe registration."""

    def __init__(self) -> None:
        self.entries: Dict[str, Dict[str, Any]] = {}

    def shaped(self, recipe_id: str, result_id: str, count: int, pattern: Iterable[str], keys: Mapping[str, str]) -> None:
        self.entries[recipe_id] = {
            "type": "shaped",
            "result": result_id,
            "count": count,
            "pattern": list(pattern),
            "keys": dict(keys),
        }

    def shapeless(self, recipe_id: str, result_id: str, count: int, ingredients: Iterable[str]) -> None:
        self.entries[recipe_id] = {
            "type": "shapeless",
            "result": result_id,
            "count": count,
            "ingredients": list(ingredients),
        }

    def remove(self, recipe_id: str) -> None:
        self.entries.pop(recipe_id, None)


class _ItemsApi:
    """Shim for dynamic item, food, and tool registration."""

    def __init__(self) -> None:
        self.entries: Dict[str, Dict[str, Any]] = {}

    def register_item(self, item_id: str, properties: Mapping[str, Any]) -> None:
        self.entries[item_id] = {"kind": "item", "properties": dict(properties)}

    def register_food(self, item_id: str, nutrition: int, saturation: float, properties: Mapping[str, Any]) -> None:
        self.entries[item_id] = {
            "kind": "food",
            "nutrition": nutrition,
            "saturation": saturation,
            "properties": dict(properties),
        }

    def register_tool(self, item_id: str, tool_type: str, properties: Mapping[str, Any]) -> None:
        self.entries[item_id] = {"kind": tool_type, "properties": dict(properties)}


class _BlocksApi:
    """Shim for block registration."""

    def __init__(self) -> None:
        self.entries: Dict[str, Dict[str, Any]] = {}

    def register_block(self, block_id: str, properties: Mapping[str, Any]) -> None:
        self.entries[block_id] = {"properties": dict(properties)}


class _TagsApi:
    """Shim for generated tag editing and lookup."""

    def __init__(self) -> None:
        self.item_tags: Dict[str, List[str]] = {}
        self.block_tags: Dict[str, List[str]] = {}
        self.unify_requests: List[tuple[str, str]] = []

    def add_item_tag(self, tag_id: str, *entries: str) -> None:
        self.item_tags.setdefault(tag_id, []).extend(str(entry) for entry in entries)

    def add_block_tag(self, tag_id: str, *entries: str) -> None:
        self.block_tags.setdefault(tag_id, []).extend(str(entry) for entry in entries)

    def get_items_by_tag(self, tag_id: str) -> List[str]:
        return list(self.item_tags.get(tag_id, []))

    def unify(self, tag_id: str, canonical_name: str) -> None:
        self.unify_requests.append((tag_id, canonical_name))


class _TexturesApi:
    """Shim for runtime texture helpers."""

    def __init__(self) -> None:
        self.entries: Dict[str, Any] = {}

    def get_texture_bytes(self, texture_id: str) -> Optional[bytes]:
        value = self.entries.get(texture_id)
        return value if isinstance(value, (bytes, bytearray)) else None

    getTexturePythonBytes = get_texture_bytes

    def register_texture(self, texture_id: str, py_bytes: bytes | bytearray | None) -> None:
        self.entries[texture_id] = bytes(py_bytes or b"")

    registerTexturePythonBytes = register_texture

    def load_texture(self, texture_id: str) -> Optional[TextureHandle]:
        if texture_id not in self.entries:
            return None
        return TextureHandle(texture_id)

    def register_image(self, texture_id: str, image: Any) -> None:
        self.entries[texture_id] = image


class _TabsApi:
    """Shim for creative tab registration."""

    def __init__(self) -> None:
        self.entries: Dict[str, Dict[str, Any]] = {}

    def create(self, tab_id: str, properties: Mapping[str, Any]) -> None:
        self.entries[tab_id] = dict(properties)


class _PyFishContentModule:
    """Combined content namespace exposed by PyFish."""

    def __init__(self) -> None:
        self.recipes = _RecipesApi()
        self.items = _ItemsApi()
        self.blocks = _BlocksApi()
        self.tags = _TagsApi()
        self.textures = _TexturesApi()
        self.tabs = _TabsApi()


class MinecraftAPI:
    """IDE shim for the runtime `mc` helper object."""

    def __init__(self) -> None:
        self._callbacks: Dict[str, List[Callback]] = {}

    def set_block(self, world: WorldHandle, x: int, y: int, z: int, block_id: str) -> None:
        world.blocks[(x, y, z)] = block_id

    def get_block_id(self, world: WorldHandle, x: int, y: int, z: int) -> str:
        return world.blocks.get((x, y, z), "minecraft:air")

    def break_block(self, world: WorldHandle, x: int, y: int, z: int) -> None:
        world.blocks.pop((x, y, z), None)

    def send_message(self, player: PlayerHandle, message: str) -> None:
        log_print(f"[to {player.name}] {message}")

    def broadcast_message(self, world: WorldHandle, message: str) -> None:
        log_print(f"[broadcast {world.name}] {message}")

    def give_item(self, player: PlayerHandle, item_id: str, count: int) -> None:
        player.inventory.append((item_id, count))

    def get_time(self, world: WorldHandle) -> int:
        return world.time

    def set_time(self, world: WorldHandle, time: int) -> None:
        world.time = int(time)

    def get_players(self, world: WorldHandle) -> List[PlayerHandle]:
        return list(world.players)

    def teleport(self, player: PlayerHandle, x: float, y: float, z: float) -> None:
        player.x = float(x)
        player.y = float(y)
        player.z = float(z)

    def set_health(self, player: PlayerHandle, health: float) -> None:
        player.health = float(health)

    def set_food_level(self, player: PlayerHandle, food_level: int) -> None:
        player.hunger = int(food_level)

    def set_experience(self, player: PlayerHandle, level: int) -> None:
        player.experience_level = int(level)

    def add_effect(self, player: PlayerHandle, effect_id: str, duration: int, amplifier: int = 0) -> None:
        log_print(f"[effect] {player.name} <- {effect_id} ({duration}t, amp={amplifier})")

    def spawn_entity(self, world: WorldHandle, entity_type_id: str, x: float, y: float, z: float) -> EntityHandle:
        entity = EntityHandle(name=entity_type_id, x=float(x), y=float(y), z=float(z), level=world)
        world.entities.append(entity)
        return entity

    def kill_entity(self, entity: EntityHandle) -> None:
        entity.alive = False
        log_print(f"[kill] {entity.name}")

    def get_entities_in_range(self, world: WorldHandle, x: float, y: float, z: float, range: float) -> List[EntityHandle]:
        matching: List[EntityHandle] = []
        range_sq = float(range) * float(range)
        for entity in world.entities:
            dx = entity.x - float(x)
            dy = entity.y - float(y)
            dz = entity.z - float(z)
            if dx * dx + dy * dy + dz * dz <= range_sq:
                matching.append(entity)
        return matching

    def execute_command(self, server: ServerHandle, command: str) -> None:
        log_print(f"[command] {command}")

    def create_explosion(
        self,
        world: WorldHandle,
        x: float,
        y: float,
        z: float,
        radius: float,
        fire: bool = False,
        mode: str = "block",
    ) -> None:
        log_print(f"[explosion] {world.name} {x} {y} {z} radius={radius} fire={fire} mode={mode}")

    def strike_lightning(self, world: WorldHandle, x: float, y: float, z: float) -> None:
        log_print(f"[lightning] {world.name} {x} {y} {z}")

    def play_sound(
        self,
        world: WorldHandle,
        x: float,
        y: float,
        z: float,
        sound_id: str,
        category: str = "master",
        volume: float = 1.0,
        pitch: float = 1.0,
    ) -> None:
        log_print(f"[sound] {sound_id} category={category} volume={volume} pitch={pitch}")

    def spawn_particle(
        self,
        world: WorldHandle,
        particle_id: str,
        x: float,
        y: float,
        z: float,
        count: int = 1,
        dx: float = 0.0,
        dy: float = 0.0,
        dz: float = 0.0,
        speed: float = 0.0,
    ) -> None:
        log_print(f"[particle] {particle_id} count={count} spread=({dx}, {dy}, {dz}) speed={speed}")

    def on(self, event: str, callback: Callback) -> None:
        self._callbacks.setdefault(event, []).append(callback)


mc = MinecraftAPI()
content = _PyFishContentModule()
recipes = content.recipes
items = content.items
blocks = content.blocks
tags = content.tags
textures = content.textures
tabs = content.tabs

__all__ = [
    "AnimalTameEvent",
    "BlockEvent",
    "BlockBreakEvent",
    "BlockPlaceEvent",
    "BlockPosHandle",
    "BlockProperties",
    "CallbackEvent",
    "CommandEvent",
    "EntityDimensionChangeEvent",
    "EntityEvent",
    "EntityHandle",
    "EntitySpawnEvent",
    "EntityTravelToDimensionEvent",
    "EventCallbacks",
    "ExplosionEvent",
    "GameProfileHandle",
    "ItemProperties",
    "ItemEntityPickupEvent",
    "ItemTossEvent",
    "ItemUseOnContextHandle",
    "LevelEvent",
    "LivingDamageEvent",
    "LivingDeathEvent",
    "LivingEvent",
    "LivingFallEvent",
    "LivingHealEvent",
    "MessageHandle",
    "MinecraftAPI",
    "NoteBlockEvent",
    "PlayerChatEvent",
    "PlayerCloneEvent",
    "PlayerEvent",
    "PlayerHandle",
    "PlayerInteractBlockEvent",
    "PlayerInteractEntityEvent",
    "PlayerInteractEvent",
    "PlayerSleepInBedEvent",
    "PlayerWakeUpEvent",
    "PlayerXpEvent",
    "PyFishModMetadata",
    "ServerEvent",
    "ServerHandle",
    "TabProperties",
    "TextureHandle",
    "WorldHandle",
    "blocks",
    "content",
    "items",
    "log_print",
    "mc",
    "recipes",
    "tags",
    "tabs",
    "textures",
]
