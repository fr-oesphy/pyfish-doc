"""IDE-friendly implementation of the bundled `java_uuid` module."""

from __future__ import annotations

import uuid as _uuid


class UUID:
    """Small compatibility wrapper around Python's stdlib UUID."""

    def __init__(self, hex: str | None = None, bytes: bytes | None = None, version: int | None = None, _uuid_value: _uuid.UUID | None = None):
        if _uuid_value is not None:
            self._uuid = _uuid_value
        elif hex is not None:
            clean_hex = str(hex).replace("-", "").replace("urn:", "").replace("uuid:", "").strip("{}")
            if len(clean_hex) != 32:
                raise ValueError("Badly formed hexadecimal UUID string")
            self._uuid = _uuid.UUID(hex=clean_hex, version=version)
        elif bytes is not None:
            if len(bytes) != 16:
                raise ValueError("bytes is not a 16-byte sequence")
            self._uuid = _uuid.UUID(bytes=bytes, version=version)
        else:
            raise TypeError("UUID() requires hex, bytes, or _uuid")

    @property
    def hex(self) -> str:
        return self._uuid.hex

    @property
    def bytes(self) -> bytes:
        return self._uuid.bytes

    @property
    def urn(self) -> str:
        return self._uuid.urn

    def __str__(self) -> str:
        return str(self._uuid)

    def __repr__(self) -> str:
        return f"UUID('{self}')"

    def __eq__(self, other: object) -> bool:
        return isinstance(other, UUID) and self._uuid == other._uuid

    def __hash__(self) -> int:
        return hash(self._uuid)


def uuid4() -> UUID:
    return UUID(_uuid_value=_uuid.uuid4())


def uuid3(namespace: UUID, name: str) -> UUID:
    if not isinstance(namespace, UUID):
        raise TypeError("namespace must be a UUID")
    return UUID(_uuid_value=_uuid.uuid3(namespace._uuid, str(name)))


__all__ = ["UUID", "uuid3", "uuid4"]
