# PyFish IDE Support

This folder is meant to be distributed as-is, including inside a zip.

Its job is simple:

- make `pyfish` imports work in an IDE
- provide autocomplete
- provide hover documentation
- reduce false import errors while writing PyFish scripts

It is **not** the real Minecraft runtime.

## Quick Start

If you downloaded `ide_support` as a zip:

1. Extract the zip anywhere on your computer.
2. Open the extracted `ide_support` folder.
3. Install it:
   - on Windows: double-click `install_editable.bat`
   - on any platform: open a terminal in this folder and run `python -m pip install -e .`
4. Verify the install:
   - run `python verify_install.py`
5. In your IDE, select the **same Python interpreter** used for the install.

After that, your PyFish scripts should resolve imports like:

- `from pyfish import mc`
- `from pyfish import items, blocks, recipes, tags, textures, tabs`
- `from pyfish import PlayerHandle, PlayerChatEvent, BlockBreakEvent`
- `import java_uuid`
- `import java_pathlib`

You can also annotate callback arguments directly now:

```python
from pyfish import mc, PlayerChatEvent, BlockBreakEvent

def on_player_chat(event: PlayerChatEvent):
    player = event.getPlayer()
    world = event.getLevel()
    text = event.getMessageString()
    if player is not None:
        mc.send_message(player, f"You said: {text}")

def on_block_break(event: BlockBreakEvent):
    player = event.getPlayer()
    pos = event.getPos()
    if player is not None and pos is not None:
        mc.send_message(player, f"Broken at {pos.getX()} {pos.getY()} {pos.getZ()}")
```

## Fastest Install Methods

### Windows

Double-click:

- `install_editable.bat`

That script:

- finds Python
- installs the package in editable mode
- offers to run a verification pass

### Manual Install

Open a terminal **inside this folder** and run:

```bash
python -m pip install -e .
```

If `python` is not the right command on your machine, use:

```bash
py -3 -m pip install -e .
```

If you installed Python from the Microsoft Store and `python` is still not found, try:

```bat
"%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe" -m pip install -e .
```

## Verify The Install

From inside this folder:

```bash
python verify_install.py
```

Expected result:

- the script prints `OK` lines for the main modules
- it exits without an exception

The verification checks:

- `pyfish`
- `java_uuid`
- `java_pathlib`
- `java_sqlite3`
- `java_asyncio`
- `java_logging`
- `java_subprocess`
- `java_multiprocessing`
- `java_pyperclip`
- `java_requests`
- `java_pillow`
- `java_websocket`

## Connect It To Your IDE

The most important rule is:

- your IDE must use the **same interpreter** where you installed `ide_support`

### VS Code

1. Open your PyFish script folder in VS Code.
2. Press `Ctrl+Shift+P`.
3. Run `Python: Select Interpreter`.
4. Pick the interpreter where you installed this package.
5. Re-open a PyFish script.

Quick check inside the editor:

- hover over `mc`
- try `from pyfish import mc`
- type `mc.` and confirm suggestions appear
- type `event.` inside a callback annotated with `PlayerChatEvent` or `BlockBreakEvent`

### PyCharm / IntelliJ Python

1. Open your project.
2. Go to `Settings` -> `Project` -> `Python Interpreter`.
3. Select the interpreter where you installed this package.
4. Apply the change.
5. Re-open a PyFish script.

Quick check:

- `from pyfish import mc` should no longer be unresolved
- hover text should appear for documented helpers
- callback event methods like `getPlayer()`, `getEntity()`, `getLevel()`, `getPos()`, and `getMessageString()` should autocomplete when the callback is annotated

## What This Package Exposes

Core modules:

- `pyfish`

Typed handle and callback classes:

- `PlayerHandle`
- `EntityHandle`
- `WorldHandle`
- `ServerHandle`
- `BlockPosHandle`
- `ItemUseOnContextHandle`
- `PlayerEvent`
- `PlayerChatEvent`
- `BlockBreakEvent`
- `BlockPlaceEvent`
- `EntitySpawnEvent`
- `EntityDimensionChangeEvent`
- `LivingDamageEvent`
- `LivingDeathEvent`
- `PlayerInteractBlockEvent`
- `PlayerInteractEntityEvent`

Bundled helper shims:

- `java_asyncio`
- `java_logging`
- `java_multiprocessing`
- `java_pathlib`
- `java_pillow`
- `java_pyperclip`
- `java_requests`
- `java_sqlite3`
- `java_subprocess`
- `java_uuid`
- `java_websocket`

## What This Package Does Not Do

This package does **not**:

- launch Minecraft
- talk to a live world
- register real items or blocks in a running game
- emulate full server or client behavior

It only gives your local Python environment enough information to understand the PyFish API surface.

## What Is Better In This Version

The IDE support now includes:

- typed player/entity/world/server handles
- typed event wrappers for common callbacks
- `PyFishModMetadata` for annotating the manifest injected into `.pyz` entrypoints
- better autocomplete for methods like `getX()`, `getY()`, `getZ()`, `getEntity()`, `getPlayer()`, `getLevel()`, `getPos()`, and `getMessageString()`
- richer content API hints for `items`, `blocks`, `recipes`, `tags`, `textures`, and `tabs`
- runtime-safe type imports, because the real PyFish runtime now exposes the same typing helper names

## Optional Dependency Notes

Some helper shims can reuse local Python packages if they are already installed:

- `java_requests` can reuse `requests`
- `java_pillow` can reuse `Pillow`
- `java_websocket` can reuse `websocket-client`

If those packages are not installed locally, the shim still imports cleanly and only complains when you try to use the missing optional feature.

## Update

If you receive a newer `ide_support` folder:

1. replace the old extracted folder with the new one
2. run the install again

Windows:

- double-click `install_editable.bat`

Manual:

```bash
python -m pip install -e .
```

## Uninstall

To remove the package from the current interpreter:

```bash
python -m pip uninstall pyfish-ide-support
```

## Troubleshooting

### `python` is not recognized

Try:

```bash
py -3 -m pip install -e .
```

If you use Microsoft Store Python, also try:

```bat
"%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe" -m pip install -e .
```

If that path still does not work, check Windows:

1. Open `Settings`
2. Go to `Apps` -> `Advanced app settings` -> `App execution aliases`
3. Enable the Python aliases

### Imports still do not resolve in the IDE

Usually one of these is wrong:

- the package was installed into a different interpreter than the IDE uses
- the IDE has not refreshed its Python environment yet
- the install was run from the wrong folder

Fix order:

1. run `python verify_install.py`
2. confirm it succeeds
3. select that same interpreter in the IDE
4. restart the IDE if needed

### I installed from the repository root instead of from inside `ide_support`

That is also valid. From the repository root, the command is:

```bash
python -m pip install -e documentation/ide_support
```

### I only want the shortest possible instructions for users

Tell them:

1. extract `ide_support`
2. double-click `install_editable.bat`
3. run `python verify_install.py`
4. select that same interpreter in the IDE
