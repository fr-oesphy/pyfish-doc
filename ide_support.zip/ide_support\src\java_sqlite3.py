"""IDE-friendly facade mirroring the bundled `java_sqlite3` module."""

from sqlite3 import (
    Connection,
    Cursor,
    DataError,
    DatabaseError,
    Error,
    IntegrityError,
    InternalError,
    NotSupportedError,
    OperationalError,
    ProgrammingError,
    connect,
)

__all__ = [
    "Connection",
    "Cursor",
    "DataError",
    "DatabaseError",
    "Error",
    "IntegrityError",
    "InternalError",
    "NotSupportedError",
    "OperationalError",
    "ProgrammingError",
    "connect",
]
