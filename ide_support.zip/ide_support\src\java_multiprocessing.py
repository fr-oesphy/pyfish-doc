"""IDE-friendly facade mirroring the bundled `java_multiprocessing` module."""

from multiprocessing import Lock, Pool, Process, Queue

__all__ = ["Lock", "Pool", "Process", "Queue"]
