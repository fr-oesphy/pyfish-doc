"""IDE-friendly facade mirroring the bundled `java_requests` module."""

from __future__ import annotations

import json as _json
from concurrent.futures import Future, ThreadPoolExecutor
from typing import Any, Mapping

try:
    import requests as _requests
except Exception:  # pragma: no cover - optional dependency shim
    _requests = None

_executor = ThreadPoolExecutor(max_workers=4)


class Response:
    """Small response wrapper compatible with the bundled API."""

    def __init__(self, raw: Any):
        self._raw = raw
        self.status_code = int(getattr(raw, "status_code", 0))
        self.text = str(getattr(raw, "text", ""))
        self.headers = dict(getattr(raw, "headers", {}) or {})
        self._json_cache: Any = None

    def json(self) -> Any:
        if self._json_cache is None:
            self._json_cache = _json.loads(self.text)
        return self._json_cache

    def __repr__(self) -> str:
        return f"<Response [{self.status_code}]>"


class FutureResponse:
    """Simple future wrapper matching the bundled helper."""

    def __init__(self, future: Future):
        self._future = future

    def is_done(self) -> bool:
        return self._future.done()

    def result(self) -> Response:
        return self._future.result()


def _require_requests() -> Any:
    if _requests is None:
        raise RuntimeError("Install the 'requests' package in the IDE interpreter to use java_requests outside Minecraft.")
    return _requests


def get(url: str, headers: Mapping[str, str] | None = None, **kwargs: Any) -> Response:
    requests = _require_requests()
    return Response(requests.get(url, headers=headers, **kwargs))


def post(url: str, data: Any = None, json: Any = None, headers: Mapping[str, str] | None = None, **kwargs: Any) -> Response:
    requests = _require_requests()
    return Response(requests.post(url, data=data, json=json, headers=headers, **kwargs))


def put(url: str, data: Any = None, json: Any = None, headers: Mapping[str, str] | None = None, **kwargs: Any) -> Response:
    requests = _require_requests()
    return Response(requests.put(url, data=data, json=json, headers=headers, **kwargs))


def delete(url: str, headers: Mapping[str, str] | None = None, **kwargs: Any) -> Response:
    requests = _require_requests()
    return Response(requests.delete(url, headers=headers, **kwargs))


def get_async(url: str, headers: Mapping[str, str] | None = None, **kwargs: Any) -> FutureResponse:
    return FutureResponse(_executor.submit(get, url, headers=headers, **kwargs))


def post_async(url: str, data: Any = None, json: Any = None, headers: Mapping[str, str] | None = None, **kwargs: Any) -> FutureResponse:
    return FutureResponse(_executor.submit(post, url, data=data, json=json, headers=headers, **kwargs))


def put_async(url: str, data: Any = None, json: Any = None, headers: Mapping[str, str] | None = None, **kwargs: Any) -> FutureResponse:
    return FutureResponse(_executor.submit(put, url, data=data, json=json, headers=headers, **kwargs))


def delete_async(url: str, headers: Mapping[str, str] | None = None, **kwargs: Any) -> FutureResponse:
    return FutureResponse(_executor.submit(delete, url, headers=headers, **kwargs))


__all__ = [
    "FutureResponse",
    "Response",
    "delete",
    "delete_async",
    "get",
    "get_async",
    "post",
    "post_async",
    "put",
    "put_async",
]
