@echo off
setlocal
cd /d "%~dp0"

echo.
echo ==========================================
echo   PyFish IDE Support Installer
echo ==========================================
echo.
echo Folder: %CD%
echo.

set "PY_EXE="
set "PY_ARGS="

where py >nul 2>nul
if %errorlevel%==0 (
    set "PY_EXE=py"
    set "PY_ARGS=-3"
)

if not defined PY_EXE (
    where python >nul 2>nul
    if %errorlevel%==0 (
        set "PY_EXE=python"
    )
)

if not defined PY_EXE (
    where python3 >nul 2>nul
    if %errorlevel%==0 (
        set "PY_EXE=python3"
    )
)

if not defined PY_EXE (
    if exist "%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe" (
        set "PY_EXE=%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe"
    )
)

if not defined PY_EXE (
    if exist "%LOCALAPPDATA%\Microsoft\WindowsApps\python3.exe" (
        set "PY_EXE=%LOCALAPPDATA%\Microsoft\WindowsApps\python3.exe"
    )
)

if defined PY_EXE (
    call "%PY_EXE%" %PY_ARGS% -V >nul 2>nul
    if errorlevel 1 (
        set "PY_EXE="
        set "PY_ARGS="
    )
)

if not defined PY_EXE (
    echo ERROR: Python was not found.
    echo.
    echo This installer looks for:
    echo   - py -3
    echo   - python
    echo   - python3
    echo   - %LOCALAPPDATA%\Microsoft\WindowsApps\python.exe
    echo   - %LOCALAPPDATA%\Microsoft\WindowsApps\python3.exe
    echo.
    echo If you use Microsoft Store Python, make sure App Execution Aliases are enabled in Windows.
    echo You can also install manually with one of these commands:
    echo   py -3 -m pip install -e .
    echo   python -m pip install -e .
    echo   "%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe" -m pip install -e .
    echo.
    pause
    exit /b 1
)

echo Using interpreter command: "%PY_EXE%" %PY_ARGS%
echo.
echo Installing pyfish-ide-support in editable mode...
call "%PY_EXE%" %PY_ARGS% -m pip install -e .
if errorlevel 1 (
    echo.
    echo ERROR: Installation failed.
    echo Try running this manually in a terminal opened in this folder:
    echo   "%PY_EXE%" %PY_ARGS% -m pip install -e .
    echo.
    pause
    exit /b 1
)

echo.
echo Installation completed successfully.
echo.
echo Recommended next steps:
echo   1. Run verification
echo   2. Select this same interpreter in your IDE
echo.

choice /M "Run verify_install.py now"
if errorlevel 2 goto end

echo.
call "%PY_EXE%" %PY_ARGS% verify_install.py
echo.

:end
echo Done.
pause
exit /b 0
