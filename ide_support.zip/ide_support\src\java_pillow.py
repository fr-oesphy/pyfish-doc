"""IDE-friendly facade mirroring the bundled `java_pillow` module."""

from __future__ import annotations

from typing import Any

try:
    from PIL import Image as _ImageModule
    from PIL import UnidentifiedImageError
except Exception:  # pragma: no cover - optional dependency shim
    _ImageModule = None

    class UnidentifiedImageError(Exception):
        """Raised when Pillow is unavailable or the image cannot be decoded."""


class _MissingImageModule:
    def open(self, *args: Any, **kwargs: Any) -> Any:
        raise RuntimeError("Install Pillow in the IDE interpreter to use java_pillow outside Minecraft.")

    def new(self, *args: Any, **kwargs: Any) -> Any:
        raise RuntimeError("Install Pillow in the IDE interpreter to use java_pillow outside Minecraft.")


Image = _ImageModule if _ImageModule is not None else _MissingImageModule()


def open(fp: Any, mode: str = "r") -> Any:
    return Image.open(fp, mode=mode)


def new(mode: str, size: tuple[int, int], color: Any = 0) -> Any:
    return Image.new(mode, size, color=color)


__all__ = ["Image", "UnidentifiedImageError", "new", "open"]
