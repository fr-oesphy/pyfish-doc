"""IDE-friendly facade mirroring the bundled `java_pyperclip` module."""

from __future__ import annotations

_clipboard = ""

try:
    import pyperclip as _pyperclip
except Exception:  # pragma: no cover - optional dependency shim
    _pyperclip = None


def copy(text: str) -> None:
    global _clipboard
    _clipboard = str(text)
    if _pyperclip is not None:
        _pyperclip.copy(_clipboard)


def paste() -> str:
    if _pyperclip is not None:
        try:
            return str(_pyperclip.paste())
        except Exception:
            return _clipboard
    return _clipboard


__all__ = ["copy", "paste"]
