"""IDE-friendly facade mirroring the bundled `java_subprocess` module."""

from subprocess import CalledProcessError, CompletedProcess, check_output, run

__all__ = ["CalledProcessError", "CompletedProcess", "check_output", "run"]
