"""IDE-friendly facade mirroring the bundled `java_logging` module."""

from logging import CRITICAL, DEBUG, ERROR, INFO, WARNING, basicConfig, critical, debug, error, exception, getLogger, info, warning

__all__ = [
    "CRITICAL",
    "DEBUG",
    "ERROR",
    "INFO",
    "WARNING",
    "basicConfig",
    "critical",
    "debug",
    "error",
    "exception",
    "getLogger",
    "info",
    "warning",
]
