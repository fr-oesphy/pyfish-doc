"""IDE-friendly facade mirroring the bundled `java_websocket` module."""

from __future__ import annotations

from typing import Any, Callable, Optional

try:
    from websocket import WebSocketApp as _RealWebSocketApp
    from websocket import create_connection as _real_create_connection
except Exception:  # pragma: no cover - optional dependency shim
    _RealWebSocketApp = None
    _real_create_connection = None


class WebSocketApp:
    """Compatibility wrapper around websocket-client's WebSocketApp."""

    def __init__(
        self,
        url: str,
        on_open: Optional[Callable[..., Any]] = None,
        on_message: Optional[Callable[..., Any]] = None,
        on_error: Optional[Callable[..., Any]] = None,
        on_close: Optional[Callable[..., Any]] = None,
        **kwargs: Any,
    ) -> None:
        self.url = url
        self.on_open = on_open
        self.on_message = on_message
        self.on_error = on_error
        self.on_close = on_close
        self.kwargs = kwargs
        self._app = None if _RealWebSocketApp is None else _RealWebSocketApp(
            url,
            on_open=on_open,
            on_message=on_message,
            on_error=on_error,
            on_close=on_close,
            **kwargs,
        )

    def run_forever(self, *args: Any, **kwargs: Any) -> Any:
        if self._app is None:
            raise RuntimeError("Install websocket-client in the IDE interpreter to use java_websocket outside Minecraft.")
        return self._app.run_forever(*args, **kwargs)

    def send(self, data: Any) -> None:
        if self._app is None:
            raise RuntimeError("Install websocket-client in the IDE interpreter to use java_websocket outside Minecraft.")
        self._app.send(data)

    def close(self) -> None:
        if self._app is not None:
            self._app.close()


def create_connection(url: str, timeout: float | None = None, **kwargs: Any) -> Any:
    if _real_create_connection is None:
        raise RuntimeError("Install websocket-client in the IDE interpreter to use java_websocket outside Minecraft.")
    return _real_create_connection(url, timeout=timeout, **kwargs)


__all__ = ["WebSocketApp", "create_connection"]
