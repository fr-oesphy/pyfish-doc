"""Legacy ModularPy compatibility shim for IDEs."""

from pyfish import blocks, content, items, recipes, tabs, tags, textures

__all__ = ["content", "recipes", "items", "blocks", "tags", "textures", "tabs"]
