"""IDE-friendly facade mirroring the bundled `java_asyncio` module."""

from asyncio import AbstractEventLoop, Future, Task, create_task, gather, get_event_loop, new_event_loop, run, set_event_loop, sleep

__all__ = [
    "AbstractEventLoop",
    "Future",
    "Task",
    "create_task",
    "gather",
    "get_event_loop",
    "new_event_loop",
    "run",
    "set_event_loop",
    "sleep",
]
