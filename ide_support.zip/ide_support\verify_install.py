"""Quick verification script for the PyFish IDE support package.

Run this after installing the package with:
    python -m pip install -e .
"""

from __future__ import annotations

import importlib
import sys


MODULES = [
    "pyfish",
    "java_asyncio",
    "java_logging",
    "java_multiprocessing",
    "java_pathlib",
    "java_pillow",
    "java_pyperclip",
    "java_requests",
    "java_sqlite3",
    "java_subprocess",
    "java_uuid",
    "java_websocket",
]


def main() -> int:
    print("PyFish IDE Support verification")
    print(f"Python executable: {sys.executable}")
    print(f"Python version: {sys.version.split()[0]}")
    print()

    failures: list[tuple[str, str]] = []

    for module_name in MODULES:
        try:
            module = importlib.import_module(module_name)
        except Exception as exc:  # pragma: no cover - simple CLI helper
            failures.append((module_name, f"{type(exc).__name__}: {exc}"))
            print(f"[FAIL] {module_name}: {type(exc).__name__}: {exc}")
            continue

        module_path = getattr(module, "__file__", "<unknown>")
        print(f"[ OK ] {module_name}: {module_path}")

    print()
    try:
        from pyfish import mc, items, blocks, recipes, tags, textures, tabs

        print("[ OK ] pyfish API surface imported")
        print(f"       mc type: {type(mc).__name__}")
        print(f"       items type: {type(items).__name__}")
        print(f"       blocks type: {type(blocks).__name__}")
        print(f"       recipes type: {type(recipes).__name__}")
        print(f"       tags type: {type(tags).__name__}")
        print(f"       textures type: {type(textures).__name__}")
        print(f"       tabs type: {type(tabs).__name__}")
    except Exception as exc:  # pragma: no cover - simple CLI helper
        failures.append(("pyfish API surface", f"{type(exc).__name__}: {exc}"))
        print(f"[FAIL] pyfish API surface: {type(exc).__name__}: {exc}")

    print()
    if failures:
        print("Verification finished with failures.")
        print("Most common fix: select the same Python interpreter in your IDE.")
        return 1

    print("Verification successful.")
    print("You can now point your IDE to this same Python interpreter.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
