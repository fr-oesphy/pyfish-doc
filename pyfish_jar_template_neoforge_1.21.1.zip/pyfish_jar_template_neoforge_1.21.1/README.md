# PyFish NeoForge 1.21.1 JAR Template

This project packages Python scripts as one native NeoForge 1.21.1 mod JAR. It does not require Java source code.

## Requirements

- Java 21
- NeoForge 21.1.215 or newer within the 21.1 release line
- PyFish 1.2.4 or newer for NeoForge 1.21.1

## Create your mod

1. Edit the mod identity fields at the top of `gradle.properties`.
2. Rename `src/main/resources/pyfish/template_mod/` to `src/main/resources/pyfish/<mod_id>/`.
3. Write Python files in that folder's `scripts/` directory.
4. Put resources in `src/main/resources/assets/<mod_id>/...` and data in `src/main/resources/data/<mod_id>/...`.
5. Run `gradlew.bat build` on Windows or `./gradlew build` on Linux and macOS.

The result is `build/libs/<mod_id>-neoforge-1.21.1-<mod_version>.jar`. Install it beside PyFish. Use a different template instead of changing the target fields in `gradle.properties`.

PyFish uses the directory name under `src/main/resources/pyfish/` as the default
content namespace. Keep that directory identical to `mod_id`.

Texture properties use resource ids, not filenames. For
`assets/<mod_id>/textures/item/ruby.png`, use `"texture": "item/ruby"` without
`assets/`, `textures/`, or `.png`. Minecraft 1.21 data folders are singular,
for example `recipe/`, `loot_table/`, `advancement/`, `tags/item/`, and `tags/block/`.
