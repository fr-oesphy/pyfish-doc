# PyFish Python-Only Mod Template

This template builds a Python-only PyFish mod as one distributable `.pyz` file.
The player or server owner only needs to place that file in the normal `mods/` folder and
install the normal PyFish mod for their loader and Minecraft version.

## Quick start

1. Edit `src/pyfish.mod.json` and choose a unique lowercase mod id.
2. Write the mod in `src/__main__.py`.
3. Optionally add Python packages or modules below `src/`.
4. Optionally add `src/requirements.txt` for pure-Python dependencies.
5. Optionally add static resources in `src/assets/<namespace>/...` and `src/data/<namespace>/...`.
6. Run:

```text
python build.py
```

The completed archive is written to `dist/<mod_id>-<version>.pyz`.

## Install the result

```text
.minecraft/
`-- mods/
    |-- pyfish-fabric-1.21.1-1.2.0.jar
    `-- example_pyz_mod-1.0.0.pyz
```

## Archive contract

Every PyFish `.pyz` contains these root files:

- `pyfish.mod.json`: declarative metadata read before any Python code runs
- `__main__.py`: the standard Python zipapp entrypoint
- `requirements.txt`: optional pure-Python dependencies installed per mod id

Static Minecraft resources use the normal data-pack and resource-pack layout:

- `assets/<namespace>/textures/...`
- `assets/<namespace>/models/...`
- `assets/<namespace>/lang/...`
- `data/<namespace>/recipes/...`
- `data/<namespace>/loot_tables/...`
- `data/<namespace>/tags/...`

An `__init__.py` is only needed inside an internal Python package. It is not the
mod manifest and it is not required for a one-file `__main__.py` mod.

During startup, PyFish injects these globals into `__main__.py`:

- `PYFISH_MOD`: the complete manifest as a dictionary
- `PYFISH_MOD_ID`: the validated content namespace
- `PYFISH_MOD_NAME`: the display name
- `PYFISH_MOD_VERSION`: the mod version

Unqualified content ids inherit `PYFISH_MOD_ID`, so
`items.register_item("token", {...})` registers `<mod_id>:token`.

## Multiple Python files

A `.pyz` is a ZIP archive, not a single source file internally. Larger mods can
use normal packages:

```text
src/
|-- pyfish.mod.json
|-- __main__.py
|-- assets/
|   `-- example_pyz_mod/
|       `-- textures/
|           `-- item/
|               `-- token.png
|-- data/
|   `-- example_pyz_mod/
|       `-- recipes/
|           `-- token.json
`-- example_pyz_mod/
    |-- __init__.py
    |-- content.py
    `-- events.py
```

Use the mod id as the package name to avoid import collisions with other
Python-only mods.

## Dependencies

Use the manifest when the mod must wait for another PyFish namespace or verify a
native loader mod:

```json
{
  "dependencies": {
    "pyz": [
      {"id": "shared_core", "version": ">=1.2.0 <2.0.0"},
      {"id": "ui_pack", "version": "1.4.x || 1.5.x"}
    ],
    "jar": [
      {"id": "fabric-api", "version": "[0.115.0,)"},
      {"id": "another_mod", "version": "!=2.0.0"}
    ]
  }
}
```

- A bare string such as `"shared_core"` means "present, any version".
- Use `version` for exact versions, comparisons, ranges, wildcards, or alternatives.
- Supported examples: `"1.2.3"`, `">=1.2.0"`, `">=1.2.0 <2.0.0"`, `"[1.2.0,2.0.0)"`, `"1.21.x"`, `"1.2.x || 2.0.x"`, `"!=2.0.0"`.
- `dependencies.pyz`: waits for another PyFish namespace before executing this archive
- `dependencies.jar`: requires a normal Fabric or NeoForge mod id to already be installed, and checks the loader mod version when a constraint is provided
