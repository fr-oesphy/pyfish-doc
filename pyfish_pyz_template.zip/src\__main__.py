from pyfish import PlayerEvent, PyFishModMetadata, items, log_print, mc


# These globals are provided by the .pyz loader before this file runs.
PYFISH_MOD: PyFishModMetadata
PYFISH_MOD_ID: str
PYFISH_MOD_NAME: str
PYFISH_MOD_VERSION: str


items.register_item(
    "python_token",
    {
        "texture": "minecraft:item/diamond",
        "stacksTo": 64,
    },
)


def on_player_join(event: PlayerEvent) -> None:
    player = event.getPlayer() or event.getEntity()
    if player is None:
        return

    mc.send_message(
        player,
        f"{PYFISH_MOD_NAME} {PYFISH_MOD_VERSION} is active.",
    )
    mc.give_item(player, f"{PYFISH_MOD_ID}:python_token", 1)


mc.on("on_player_join", on_player_join)
log_print(f"Loaded {PYFISH_MOD_NAME} {PYFISH_MOD_VERSION} ({PYFISH_MOD_ID})")
