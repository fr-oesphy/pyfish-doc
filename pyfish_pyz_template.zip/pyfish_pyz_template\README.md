# PyFish Python-Only Mod Template

This template builds a Python-only PyFish mod as one distributable `.pyz` file.
The player or server owner only needs to place that file in the normal `mods/` folder and
install the normal PyFish mod for their loader and Minecraft version.

## Quick start

1. Edit `src/pyfish.json` and choose a unique lowercase mod id.
2. Write the mod in `src/__main__.py`.
3. Optionally add Python packages or modules below `src/`.
4. Optionally add `src/requirements.txt` for pure-Python dependencies.
5. Run:

```text
python build.py
```

The completed archive is written to `dist/<mod_id>-<version>.pyz`.

## Install the result

```text
.minecraft/
`-- mods/
    |-- pyfish-fabric-1.21.1-1.2.0.jar
    `-- example_pyz_mod-1.0.0.pyz
```

## Archive contract

Every PyFish `.pyz` contains these root files:

- `pyfish.json`: declarative metadata read before any Python code runs
- `__main__.py`: the standard Python zipapp entrypoint
- `requirements.txt`: optional pure-Python dependencies installed per mod id

An `__init__.py` is only needed inside an internal Python package. It is not the
mod manifest and it is not required for a one-file `__main__.py` mod.

## Why the manifest uses JSON

`pyfish.json` is intentionally JSON rather than TOML. The manifest contains a
small, stable set of identity fields, and JSON can be validated before any
Python code runs without adding another parser to PyFish. It also works well
with JSON Schema, editors, build tools, and websites.

TOML remains a good choice for a separate, large user configuration file where
comments are useful. Configuration and mod identity are separate concerns, so
that does not require changing the `.pyz` manifest format.

During startup, PyFish injects these globals into `__main__.py`:

- `PYFISH_MOD`: the complete manifest as a dictionary
- `PYFISH_MOD_ID`: the validated content namespace
- `PYFISH_MOD_NAME`: the display name
- `PYFISH_MOD_VERSION`: the mod version

Unqualified content ids inherit `PYFISH_MOD_ID`, so
`items.register_item("token", {...})` registers `<mod_id>:token`.

## Multiple Python files

A `.pyz` is a ZIP archive, not a single source file internally. Larger mods can
use normal packages:

```text
src/
|-- pyfish.json
|-- __main__.py
`-- example_pyz_mod/
    |-- __init__.py
    |-- content.py
    `-- events.py
```

Use the mod id as the package name to avoid import collisions with other
Python-only mods.
