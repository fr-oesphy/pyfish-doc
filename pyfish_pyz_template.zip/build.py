from __future__ import annotations

import argparse
import json
import re
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "src"
DEFAULT_DIST = ROOT / "dist"
MANIFEST_NAME = "pyfish.mod.json"
LEGACY_MANIFEST_NAME = "pyfish.json"
MOD_ID_PATTERN = re.compile(r"[a-z0-9_.-]{1,64}")
REQUIRED_FIELDS = ("schema_version", "id", "name", "version")


def load_manifest() -> dict[str, object]:
    manifest_path = SOURCE / MANIFEST_NAME
    if not manifest_path.is_file():
        legacy_manifest = SOURCE / LEGACY_MANIFEST_NAME
        if legacy_manifest.is_file():
            manifest_path = legacy_manifest
        else:
            raise SystemExit(f"Missing src/{MANIFEST_NAME}")
    manifest_label = manifest_path.relative_to(ROOT).as_posix()

    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        raise SystemExit(f"Invalid {manifest_label}: {exc}") from exc

    if not isinstance(manifest, dict):
        raise SystemExit(f"{manifest_label} must contain a JSON object")
    for field in REQUIRED_FIELDS:
        if field not in manifest or manifest[field] in (None, ""):
            raise SystemExit(f"Missing required {manifest_label} field: {field}")
    if (
        isinstance(manifest["schema_version"], bool)
        or not isinstance(manifest["schema_version"], int)
        or manifest["schema_version"] != 1
    ):
        raise SystemExit(f"{manifest_label} schema_version must currently be 1")

    mod_id = manifest["id"]
    if not isinstance(mod_id, str) or not MOD_ID_PATTERN.fullmatch(mod_id):
        raise SystemExit(
            "Mod id must use 1-64 lowercase letters, numbers, underscores, dots, or dashes"
        )
    if mod_id in {"minecraft", "pyfish"}:
        raise SystemExit(f"Mod id {mod_id!r} is reserved")
    for field in ("name", "version"):
        value = manifest[field]
        if not isinstance(value, str) or not value.strip():
            raise SystemExit(f"{manifest_label} field {field!r} must be a non-empty string")
    for field in ("description", "license", "homepage"):
        value = manifest.get(field)
        if value is not None and not isinstance(value, str):
            raise SystemExit(f"{manifest_label} field {field!r} must be a string")

    authors = manifest.get("authors")
    if authors is not None:
        if isinstance(authors, str):
            pass
        elif not isinstance(authors, list) or not all(
            isinstance(author, str) for author in authors
        ):
            raise SystemExit(
                f"{manifest_label} field 'authors' must be a string or an array of strings"
            )

    dependencies = manifest.get("dependencies")
    if dependencies is not None:
        if not isinstance(dependencies, dict):
            raise SystemExit(f"{manifest_label} field 'dependencies' must be an object")
        for key, reject_reserved in (("pyz", True), ("jar", False)):
            values = dependencies.get(key, [])
            if not isinstance(values, list):
                raise SystemExit(
                    f"{manifest_label} field 'dependencies.{key}' must be an array"
                )
            seen: set[str] = set()
            for entry in values:
                dependency_id = validate_dependency_entry(
                    entry,
                    manifest_label,
                    key,
                    mod_id,
                    reject_reserved,
                )
                if dependency_id in seen:
                    raise SystemExit(
                        f"{manifest_label} field 'dependencies.{key}' contains duplicate dependency id {dependency_id!r}"
                    )
                seen.add(dependency_id)
    return manifest


def validate_dependency_entry(
    entry: object,
    manifest_label: str,
    key: str,
    mod_id: str,
    reject_reserved: bool,
) -> str:
    if isinstance(entry, str):
        dependency_id = entry.strip()
    elif isinstance(entry, dict):
        dependency_id = entry.get("id")
        if not isinstance(dependency_id, str) or not dependency_id.strip():
            raise SystemExit(
                f"{manifest_label} field 'dependencies.{key}' object entries must define a non-empty string 'id'"
            )
        dependency_id = dependency_id.strip()
        validate_dependency_version_fields(entry, manifest_label, key, dependency_id)
    else:
        raise SystemExit(
            f"{manifest_label} field 'dependencies.{key}' must contain strings or objects"
        )

    if not MOD_ID_PATTERN.fullmatch(dependency_id):
        raise SystemExit(
            "Dependency ids must use 1-64 lowercase letters, numbers, underscores, dots, or dashes"
        )
    if dependency_id == mod_id:
        raise SystemExit(
            f"{manifest_label} field 'dependencies.{key}' cannot depend on the mod itself"
        )
    if reject_reserved and dependency_id in {"minecraft", "pyfish"}:
        raise SystemExit(
            f"{manifest_label} field 'dependencies.{key}' cannot target reserved namespace {dependency_id!r}"
        )
    return dependency_id


def validate_dependency_version_fields(
    dependency: dict[str, object],
    manifest_label: str,
    key: str,
    dependency_id: str,
) -> None:
    seen_values: set[str] = set()
    for field in ("version", "versionRange", "version_range"):
        if field not in dependency:
            continue
        value = dependency[field]
        if value is None:
            continue
        if not isinstance(value, str):
            raise SystemExit(
                f"{manifest_label} field 'dependencies.{key}' dependency {dependency_id!r} field {field!r} must be a string"
            )
        normalized = value.strip()
        if not normalized:
            raise SystemExit(
                f"{manifest_label} field 'dependencies.{key}' dependency {dependency_id!r} field {field!r} must not be blank"
            )
        seen_values.add(normalized)

    if len(seen_values) > 1:
        raise SystemExit(
            f"{manifest_label} field 'dependencies.{key}' dependency {dependency_id!r} defines conflicting version fields"
        )


def source_files() -> list[Path]:
    files: list[Path] = []
    for path in SOURCE.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(SOURCE)
        if "__pycache__" in relative.parts or path.suffix in {".pyc", ".pyo"}:
            continue
        files.append(path)
    return sorted(files, key=lambda path: path.relative_to(SOURCE).as_posix())


def build(output: Path | None) -> Path:
    manifest = load_manifest()
    if not (SOURCE / "__main__.py").is_file():
        raise SystemExit("Missing src/__main__.py")

    target = output or DEFAULT_DIST / f"{manifest['id']}-{manifest['version']}.pyz"
    target = target.resolve()
    if target.suffix.lower() != ".pyz":
        raise SystemExit("Output filename must end with .pyz")
    target.parent.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in source_files():
            archive.write(path, path.relative_to(SOURCE).as_posix())

    print(f"Built {target}")
    print(f"Install it in <instance>/mods/{target.name}")
    return target


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a Python-only PyFish .pyz mod")
    parser.add_argument("--output", type=Path, help="Optional output .pyz path")
    args = parser.parse_args()
    build(args.output)


if __name__ == "__main__":
    main()
