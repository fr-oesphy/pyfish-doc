# PyFish Fabric 1.21.11 JAR Template

This project packages Python scripts as one native Fabric 1.21.11 mod JAR. It does not require Java source code.

## Requirements

- Java 21
- Fabric Loader 0.16.9 or newer
- Fabric API for Minecraft 1.21.11
- PyFish 1.2.2 or newer for Fabric 1.21.11

## Create your mod

1. Edit the mod identity fields at the top of `gradle.properties`.
2. Rename `src/main/resources/pyfish/template_mod/` to `src/main/resources/pyfish/<mod_id>/`.
3. Write Python files in that folder's `scripts/` directory.
4. Put resources in `src/main/resources/assets/<mod_id>/...` and data in `src/main/resources/data/<mod_id>/...`.
5. Run `gradlew.bat build` on Windows or `./gradlew build` on Linux and macOS.

The result is `build/libs/<mod_id>-fabric-1.21.11-<mod_version>.jar`. Install it beside PyFish and Fabric API. Use a different template instead of changing the target fields in `gradle.properties`.

Scripts bundled this way automatically use the loader mod id as their default content namespace.
